import React, { useState } from 'react';
import Formulario from "./components/Formulario";
import Card from './components/Card';



function App() {

  const [formData, setFormData] = useState({});


  const handleFormSubmit = (data) => {
    setFormData(data);
  };
  //Aqui deberias agregar los estados y los handlers para los inputs

  return (
    <div className="App">
      <h1>Registro de vehiculos nuevos</h1>
      <Formulario onSubmit={handleFormSubmit} /> {/* Renderiza el componente Form */}
      {Object.keys(formData).length > 0 && <Card {...formData} />} {/* Renderiza el componente Card con la información del formulario */}
      
    </div>
  );
}

export default App;
