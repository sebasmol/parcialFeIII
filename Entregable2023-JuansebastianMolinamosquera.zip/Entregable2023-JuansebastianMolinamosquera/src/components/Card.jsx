//Este componente deberia recibir por props y mostrar en pantalla la informacion
//que envia el usuario

import React from 'react';
import "../index.css";

function Card({ marca, placa, modelo, cilindraje, anoModelo }) {
  return (
    <div className='card-container'>
      <h2>Información del Auto</h2>
      <p>Marca: {marca}</p>
      <p>Placa: {placa}</p>
      <p>Modelo: {modelo}</p>
      <p>Cilindraje: {cilindraje}</p>
      <p>Año Modelo: {anoModelo}</p>
    </div>
  );
}

export default Card;
