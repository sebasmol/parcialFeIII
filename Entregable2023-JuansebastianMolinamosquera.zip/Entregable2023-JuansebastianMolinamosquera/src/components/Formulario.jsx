import React, { useState } from 'react';
import "../index.css";



const Formulario = ({ onSubmit }) => {
  const [formData, setFormData] = useState({
    marca: '',
    placa: '',
    modelo: '',
    cilindraje: '',
    anoModelo: ''
  });
  const [error, setError] = useState('');

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    // Validaciones
    if (formData.marca.length < 3) {
      setError('La marca debe tener al menos 3 caracteres.');
    } else if (formData.placa.length !== 6) {
      setError('La placa debe tener 6 caracteres.');
    } else {
      setError('');
      onSubmit(formData);
    }
  };

  return (
    <form className="form-container" onSubmit={handleSubmit}>
      <div>
        <label>
          Marca:
          <input
            type="text"
            name="marca"
            value={formData.marca}
            onChange={handleInputChange}
          />
        </label>
      </div>
      <div>
        <label>
          Placa:
          <input
            type="text"
            name="placa"
            value={formData.placa}
            onChange={handleInputChange}
          />
        </label>
      </div>
      <div>
        <label>
          Modelo:
          <input
            type="text"
            name="modelo"
            value={formData.modelo}
            onChange={handleInputChange}
          />
        </label>
      </div>
      <div>
        <label>
          Cilindraje:
          <input
            type="text"
            name="cilindraje"
            value={formData.cilindraje}
            onChange={handleInputChange}
          />
        </label>
      </div>
      <div>
        <label>
          Año Modelo:
          <input
            type="text"
            name="anoModelo"
            value={formData.anoModelo}
            onChange={handleInputChange}
          />
        </label>
      </div>
      <button type="submit">Registrar Auto</button>
      {error && <p style={{ color: 'red' }}>{error}</p>}
    </form>
  );
};

export default Formulario;
